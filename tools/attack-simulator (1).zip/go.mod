module github.com/alfimuhtadii/detector/attack-simulator

go 1.22

require (
	github.com/twmb/franz-go v1.16.1
	gopkg.in/yaml.v3 v3.0.1
)
